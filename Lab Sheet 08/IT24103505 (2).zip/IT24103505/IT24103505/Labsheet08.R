setwd("C:\\Users\\IT24103505\\Desktop\\IT24103505")

data <- read.table("Exercise - LaptopsWeights.txt",header = TRUE)
fix(data)
attach(data)

popmin <- mean(Weight.kg.)
popvar <- var(Weight.kg.)
popsd <- sd(Weight.kg.)

popmin
popvar
popsd

sample <- c()
n <- c()

for(i in 1:25){
  s <- sample(Weight.kg.,6,replace=TRUE)
  sample <- cbind(sample,s)
  n<-c(n,paste('S',i))
}

colnames(sample)=n

s.mean<-apply(sample,2,mean)
s.vars<-apply(sample,2,var)
s.sd <- apply(sample,2,sd)

samplemean<-mean(s.mean)
samplevars<-var(s.vars)
samplesd<-sd(s.sd)

samplemean
samplevars
samplesd
