setwd("C:\\Users\\yuvin\\OneDrive\\Desktop\\123")
Delivery_Times <- read.table("Exercise - Lab 05.txt",header=TRUE,sep=",")

fix(Delivery_Times)



names(Delivery_Times) <- c("X2")


hist(Delivery_Times$X2,main="Histogram for Delivery times",col="lightblue",border="black")

histogram<-hist(Delivery_Times$X2,
                main="Histogram for Delivery Times",
                xlab="Delivery Time",
                col="lightgreen",
                border="black",
                breaks=seq(20,70,length=8),
                right=TRUE)

breaks <- round(histogram$breaks)
freq<- histogram$counts

mids <- histogram$mids

classes <- c()

for (i in 1:length(breaks)-1) {
  classes[i] <- paste0("[",breaks[i],",", breaks[i+1],")")
  
}


cbind(Classes = classes,Frequency = freq)

cum.freq <- cumsum(freq)

new<-c()

for(i in 1:length(breaks)){
  if(i ==1){
    new[i] = 0
  }else{
    new[i]=cum.freq[i-1]
  }
}

plot(histogram$breaks[-1], cum.freq,
     type="l",
     main="Cumulative Frequency Polygon for Delivery Times",
     xlab="Delivery Time",
     ylab="Cumulative Frequency",
     ylim=c(0, max(cum.freq)),
     col="blue",
     lwd=2)
