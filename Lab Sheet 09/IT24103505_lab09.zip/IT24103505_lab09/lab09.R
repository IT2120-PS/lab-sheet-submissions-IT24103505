setwd("C:\\Users\\yuvin\\Downloads\\IT24103505_lab09")

#Exercise

sample <- rnorm(25, mean=45, sd=2)
sample

t.test(sample, mu=46, alternative = "less")
