setwd("C:\\Users\\yuvin\\OneDrive\\Desktop\\IT24103505")
#Question 1
#i
#random variable X has Binomial Distribution n=50 and p=0.85
#ii
dbinom(47,50,0.85)

#Question 2
#i
#Number of Calls that call center gets per an hour

#ii
#random variable X has poisson distribution with lambda=12

#iii
dpois(12,15)
