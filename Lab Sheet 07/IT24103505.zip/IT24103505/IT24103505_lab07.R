setwd("C:\\Users\\yuvin\\OneDrive\\Desktop\\IT24103505")

#Question 1

punif(25,min = 0, max=40, lower.tail = TRUE) - punif(10,min = 0,max = 40, lower.tail = TRUE)

#Question 2

pexp(2, rate=1/3,lower.tail = TRUE)


#Question 3

1-pnorm(130,mean = 100, sd = 15)

pnorm(0.95, mean = 100, sd = 15)
